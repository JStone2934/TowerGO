from setuptools import find_packages, setup
package_name = 'astribot_nav_bridge'
setup(name=package_name, version='0.0.1', packages=find_packages(exclude=['test']),
      data_files=[('share/ament_index/resource_index/packages', ['resource/' + package_name]),
                  ('share/' + package_name, ['package.xml'])],
      install_requires=['setuptools'], zip_safe=True,
      maintainer='TowerGO maintainer (replace before release)',
      maintainer_email='maintainer@example.invalid',
      description='TowerGO navigation scaffold; runtime implementation pending.',
      license='TODO', entry_points={'console_scripts': []})
