# 接口约定（待实现）

| 接口 | 类型 | 用途 |
|---|---|---|
| /livox/lidar_front, /livox/lidar_back | sensor_msgs/msg/PointCloud2 | 厂商点云 |
| /livox/imu_front, /livox/imu_back | sensor_msgs/msg/Imu | 厂商 IMU，单位需验证 |
| /scan | sensor_msgs/msg/LaserScan | SLAM 与 AMCL 输入 |
| /odom | nav_msgs/msg/Odometry | 真实连续里程计 |
| /map | nav_msgs/msg/OccupancyGrid | 导航地图 |
| /cmd_vel | geometry_msgs/msg/Twist | Humble 导航速度接口，适配时确认 |
| /navigate_to_pose | nav2_msgs/action/NavigateToPose | 标准导航任务 |

## TF 所有权

- 建图时 slam_toolbox 发布 map → odom。
- 已有地图导航时 AMCL 发布 map → odom；不同时运行建图 TF 发布者。
- 选定里程计模块发布 odom → base_link。
- robot_state_publisher 或静态 TF 提供底盘到传感器变换。
- 同一 TF 边只有一个发布者；复用已有机器人 TF 前先检查其 frame 命名与实际定义。

## 底盘接口要求

确认实际速度接口、控制周期、单位、限速、坐标方向、急停与遥控优先级、指令超时停车。
get_desired_joints_position 是目标状态，不能替代真实里程计。
若无可靠底盘反馈，应选择经验证的激光惯性里程计等来源。

## 双雷达处理要求

验证外参是否已在驱动中应用，核验采样时刻和逐点时间，避免双重变换。
两个话题改成同名不等于融合；虚拟 LaserScan 要验证不同观测原点造成的遮挡和清空误差。
Nav2 障碍物观测可分别使用前后点云。
