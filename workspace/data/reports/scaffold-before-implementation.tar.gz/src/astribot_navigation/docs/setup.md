# 环境与安装

见工作区 README。先验证厂商 ROS 环境和可用依赖，再固定 Humble 兼容版本。dependencies.repos 当前为空，没有已锁定的第三方源码。package.xml 随实现补充真实依赖。
