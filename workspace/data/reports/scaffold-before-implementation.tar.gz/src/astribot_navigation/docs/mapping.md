# 建图流程（待实现）

检查传感器与 TF → 录制数据 → 单路扫描基线 → 双路处理验证 → slam_toolbox 建图 → 保存 map.yaml 和图像。
需继续建图时另存 slam_toolbox 序列化位姿图；仅保存栅格地图不足以恢复原建图状态。
地图放入 workspace/data/maps/<地图名>/，记录标定和软件版本。
