# 导航流程（待实现）

加载地图 → 启动里程计与传感器 → AMCL 初始定位 → Nav2 lifecycle 节点就绪 → 发送 NavigateToPose → 反馈、结果或取消。
调试时检查实际机器人轮廓、传感器盲区、限速及指令超时停车。
navigation.launch.py 尚未实现。
