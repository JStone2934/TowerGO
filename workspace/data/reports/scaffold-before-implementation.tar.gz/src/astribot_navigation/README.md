# astribot_navigation

TowerGO 的 Astribot 建图与导航源码目录。完整指南见 ../../README.md。

| 包 | 职责 | 当前状态 |
|---|---|---|
| astribot_nav_bringup | launch、参数、URDF、RViz | 构建骨架 |
| astribot_nav_sensors | 时间对齐、坐标变换、点云过滤 | C++ 构建骨架 |
| astribot_nav_bridge | 速度控制和真实里程计适配 | Python 包骨架 |
| astribot_nav_api | 导航目标、取消、结果查询 | Python 包骨架 |

未提供可运行节点或启动文件。第三方 Nav2、SLAM 算法通过依赖集成，不复制其源码到自有包。
