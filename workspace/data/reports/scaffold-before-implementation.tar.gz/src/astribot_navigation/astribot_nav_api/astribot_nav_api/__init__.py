"""TowerGO navigation scaffold; nodes are not implemented yet."""
