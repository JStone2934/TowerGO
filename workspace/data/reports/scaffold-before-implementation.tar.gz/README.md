# TowerGO：Astribot SLAM 与导航工作区

## 当前状态

本工作区包含目录结构、ROS2 包构建骨架和开发文档。尚未实现双雷达融合、底盘适配、SLAM 或导航节点；尚未安装 Nav2/SLAM 依赖，也未进行硬件运行验证。
创建这些文件不会启动雷达或控制机器人。launch、config、urdf、rviz 中的文件需要后续开发，不能直接运行建图或导航。

## 目标与技术路线

第一版目标：室内平地建图、保存地图、重启后定位、导航至指定位置。
建议采用 Livox MID360 → 点云预处理 → LaserScan → slam_toolbox 建图；导航时使用地图服务器 + AMCL + Nav2，再由底盘适配节点对接 Astribot SDK。
GLIM 三维建图可作为后续替代后端；三维建图仍需额外实现已有地图重定位及导航地图生成。

## 目录

```text
workspace/
├── README.md
├── src/astribot_navigation/       # 自有源码，建议作为一个 Git 仓库
│   ├── README.md
│   ├── dependencies.repos        # 待验证后锁定第三方源码版本
│   ├── docs/                    # 安装、建图、导航、接口说明
│   ├── astribot_nav_bringup/     # 启动、配置、坐标系、RViz
│   ├── astribot_nav_sensors/     # C++ 雷达预处理
│   ├── astribot_nav_bridge/      # Python 底盘与里程计适配
│   └── astribot_nav_api/         # Python 导航任务 API
├── data/
│   ├── maps/                    # 地图、标定版本与元数据
│   ├── bags/                    # 原始数据录制
│   └── trajectories/            # 轨迹导出
├── build/                       # colcon 构建时生成
├── install/                     # colcon 构建时生成
└── log/                         # colcon 构建时生成
```

build、install、log 不手动维护，不加入版本管理。运行数据放在 data 中，不写入安装目录。
本次不初始化 Git，以便后续决定是否并入 TowerGO 的上层仓库。

## 已核查的设备信息

- SSH：astribot@10.7.154.109；Ubuntu 22.04 ARM64，ROS2 Humble。
- 厂商软件：/opt/astribot_ros；Python SDK：/home/astribot/astribot_sdk_aarch64。
- ROS_DOMAIN_ID=25。
- 前 MID360：192.168.0.12；后 MID360：192.168.0.13。
- 点云：/livox/lidar_front、/livox/lidar_back。
- IMU：/livox/imu_front、/livox/imu_back。
- /astribot_lidar_control 服务使用 std_srvs/srv/SetBool 控制双雷达驱动。
- 厂商默认启动文件为 msg_MID360_launch_rviz_msg_type.py，配置 PointCloud2、10 Hz、分话题输出；这是配置值，不代表已实测的数据质量。
- MID360_config.json 中后雷达已有非零外参。必须确认是否已经应用到点坐标，禁止重复变换。
- 两路点云配置使用 livox_frame；不能只凭 frame_id 判断实际坐标系。
- 有 PTP 相关进程不等于传感器已同步，需验证消息及逐点时间。

## 环境与构建

在机器人新终端中执行：

```bash
source /opt/astribot_ros/middle_ware/setup.bash
source /opt/astribot_ros/software/setup.bash
export ROS_DOMAIN_ID=25
cd /home/astribot/TowerGO/workspace
colcon build --symlink-install
source install/setup.bash
```

当前包只用于验证结构和安装规则，构建成功不代表导航功能可用。
设备另有 /opt/ros/humble，安装新依赖前要核查与厂商环境的兼容性，固定加载顺序。不要盲目覆盖厂商软件。
Python 底盘节点后续需要配置 Astribot SDK 的运行环境及安装依赖。

## 计划中的调用方式（尚未实现）

```bash
ros2 launch astribot_nav_bringup mapping.launch.py
ros2 launch astribot_nav_bringup navigation.launch.py \
  map:=/home/astribot/TowerGO/workspace/data/maps/office/map.yaml
```

外部程序优先通过 /navigate_to_pose 的 nav2_msgs/action/NavigateToPose 接口发送目标、接收反馈、取消任务。命名点位与多目标任务封装在 astribot_nav_api。

## 开发顺序与验收

1. 检查双雷达点云、IMU、外参、时间同步和自身点云过滤，录制可重复回放的数据。
2. 核实底盘速度控制模式、坐标方向、单位、反馈源，实现指令超时停车及控制权仲裁。
3. 提供真实 /odom 和连续的 odom → base_link；目标位置不能当成实测里程计。
4. 先验证单路扫描建图，再验证双雷达虚拟扫描的遮挡及自由空间误差。
5. 保存地图；重新启动后加载地图并验证初始定位。
6. 配置 Nav2 轮廓、代价地图、规划器、控制器，验证到点、避障、取消和异常停车。
7. 封装启动参数与 Action 调用，记录依赖版本、地图版本和验收结果。

## 资料

- https://github.com/SteveMacenski/slam_toolbox
- https://github.com/ros-perception/pointcloud_to_laserscan
- https://docs.nav2.org/
- https://github.com/koide3/glim

实现时选择与 ROS2 Humble 兼容的版本，不能直接照搬 Rolling 参数。
